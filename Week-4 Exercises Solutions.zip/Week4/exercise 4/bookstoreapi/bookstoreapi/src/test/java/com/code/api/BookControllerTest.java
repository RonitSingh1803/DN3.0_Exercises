package com.code.api;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.wavefront.WavefrontProperties.Application;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.code.api.dto.BookDTO;
import com.code.api.entity.Book;
import com.code.api.services.BookService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.MediaType;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
@WebMvcTest
@ContextConfiguration(classes=Application.class)
public class BookControllerTest {
@Autowired
 private MockMvc mockMvc;
@MockBean
 private BookService bookService;
private static ObjectMapper mapper = new ObjectMapper();
@Test
 public void testGetExample() throws Exception {
  List<BookDTO> books = new ArrayList<>();
  BookDTO book = new BookDTO();
  book.setId(1);
  book.setTitle("java");
  book.setAuthor("Abcd");
book.setIsbn("12345678");
book.setPrice(5000);
  books.add(book);
  Mockito.when(bookService.getBooks()).thenReturn(books);
  mockMvc.perform(MockMvcRequestBuilders
			.get("/api/boks/")
			.accept(MediaType.APPLICATION_JSON))
    .andDo(print())
    .andExpect(status().isOk())
    .andExpect(MockMvcResultMatchers.jsonPath("$", Matchers.hasSize(1)))
    .andExpect(MockMvcResultMatchers.jsonPath("$[0].title", Matchers.equalTo("java")));
   
 }

}